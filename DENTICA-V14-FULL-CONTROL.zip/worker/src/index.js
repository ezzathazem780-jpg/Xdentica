const C={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type,Authorization','Access-Control-Allow-Methods':'GET,POST,PUT,DELETE,OPTIONS'};
const J=(x,s=200)=>new Response(JSON.stringify(x),{status:s,headers:{...C,'Content-Type':'application/json'}});
const body=async r=>await r.json();
export default{async fetch(r,e){
 if(r.method==='OPTIONS')return new Response('',{headers:C});
 const u=new URL(r.url),p=u.pathname;
 try{
  if(p==='/api/health')return J({ok:true,version:'14',mode:'FULL_CONTROL'});
  if(p==='/api/admin/login'&&r.method==='POST'){let b=await body(r);let a=await e.DB.prepare('SELECT id,email FROM admins WHERE email=? AND password=?').bind(b.email,b.password).first();return a?J({ok:true,admin:a}):J({error:'بيانات الدخول غير صحيحة'},401)}
  if(p==='/api/dashboard')return J({patients:(await e.DB.prepare('SELECT COUNT(*) n FROM patients').first()).n,appointments:(await e.DB.prepare('SELECT COUNT(*) n FROM appointments').first()).n,doctors:(await e.DB.prepare('SELECT COUNT(*) n FROM doctors').first()).n,services:(await e.DB.prepare('SELECT COUNT(*) n FROM services').first()).n});
  if(p==='/api/patients'){
   if(r.method==='GET')return J((await e.DB.prepare('SELECT * FROM patients ORDER BY id DESC').all()).results);
   let b=await body(r); if(r.method==='POST'){await e.DB.prepare('INSERT INTO patients(name,phone,email,notes) VALUES(?,?,?,?)').bind(b.name,b.phone,b.email||'',b.notes||'').run();return J({ok:true},201)}
   if(r.method==='PUT'){await e.DB.prepare('UPDATE patients SET name=?,phone=?,email=?,notes=? WHERE id=?').bind(b.name,b.phone,b.email||'',b.notes||'',b.id).run();return J({ok:true})}
   if(r.method==='DELETE'){await e.DB.prepare('DELETE FROM patients WHERE id=?').bind(b.id).run();return J({ok:true})}
  }
  if(p==='/api/doctors'){
   if(r.method==='GET')return J((await e.DB.prepare('SELECT * FROM doctors ORDER BY id DESC').all()).results);
   let b=await body(r);
   if(r.method==='POST'){await e.DB.prepare('INSERT INTO doctors(name,specialty,phone,active) VALUES(?,?,?,?)').bind(b.name,b.specialty||'',b.phone||'',b.active??1).run();return J({ok:true})}
   if(r.method==='PUT'){await e.DB.prepare('UPDATE doctors SET name=?,specialty=?,phone=?,active=? WHERE id=?').bind(b.name,b.specialty||'',b.phone||'',b.active??1,b.id).run();return J({ok:true})}
   if(r.method==='DELETE'){await e.DB.prepare('DELETE FROM doctors WHERE id=?').bind(b.id).run();return J({ok:true})}
  }
  if(p==='/api/services'){
   if(r.method==='GET')return J((await e.DB.prepare('SELECT * FROM services ORDER BY id DESC').all()).results);
   let b=await body(r);
   if(r.method==='POST'){await e.DB.prepare('INSERT INTO services(name,description,price,active) VALUES(?,?,?,?)').bind(b.name,b.description||'',b.price||0,b.active??1).run();return J({ok:true})}
   if(r.method==='PUT'){await e.DB.prepare('UPDATE services SET name=?,description=?,price=?,active=? WHERE id=?').bind(b.name,b.description||'',b.price||0,b.active??1,b.id).run();return J({ok:true})}
   if(r.method==='DELETE'){await e.DB.prepare('DELETE FROM services WHERE id=?').bind(b.id).run();return J({ok:true})}
  }
  if(p==='/api/appointments'){
   if(r.method==='GET')return J((await e.DB.prepare(`SELECT a.*,p.name patient,s.name service,d.name doctor FROM appointments a JOIN patients p ON p.id=a.patient_id LEFT JOIN services s ON s.id=a.service_id LEFT JOIN doctors d ON d.id=a.doctor_id ORDER BY a.appointment_date DESC`).all()).results);
   let b=await body(r);
   if(r.method==='POST'){await e.DB.prepare('INSERT INTO appointments(patient_id,doctor_id,service_id,appointment_date,notes,status) VALUES(?,?,?,?,?,?)').bind(b.patient_id,b.doctor_id||null,b.service_id||null,b.appointment_date,b.notes||'',b.status||'pending').run();return J({ok:true})}
   if(r.method==='PUT'){await e.DB.prepare('UPDATE appointments SET patient_id=?,doctor_id=?,service_id=?,appointment_date=?,notes=?,status=? WHERE id=?').bind(b.patient_id,b.doctor_id||null,b.service_id||null,b.appointment_date,b.notes||'',b.status||'pending',b.id).run();return J({ok:true})}
   if(r.method==='DELETE'){await e.DB.prepare('DELETE FROM appointments WHERE id=?').bind(b.id).run();return J({ok:true})}
  }
  if(p==='/api/settings'){
   if(r.method==='GET')return J((await e.DB.prepare('SELECT * FROM settings').all()).results);
   let b=await body(r); await e.DB.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(b.key,b.value||'').run();return J({ok:true});
  }
  return J({error:'Not found'},404)
 }catch(x){return J({error:x.message},500)}
}};