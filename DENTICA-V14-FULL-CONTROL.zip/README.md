# DENTICA V14 — FULL CONTROL
Admin-first dental clinic platform.
Features: patients, appointments, doctors, services, settings, dashboard, CRUD API, D1, Android APK build.
Replace Cloudflare D1 database_id and API_BASE_URL before deployment.
